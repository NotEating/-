SHOW 

DATABASES; 
USE phpmyadmin;
#SHOW TABLES;
/*
SHOW TABLES;
*/
