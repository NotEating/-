//判断一个人是否为成年人，满18打印成年人，否则打印未成年人
var age=12;
//age>=18 ? console.log('成年人') : console.log('未成年人');
//练习：比较两个数字，分别用两个变量保存，打印最大值
var a=2;
var b=7;
//a>b ? console.log(a) : console.log(b);
//练习: 声明两个变量分别保存用户名和密码，如果用户名为root，并且密码为123456，打印登录成功，否则打印登录失败
var uname='root';
var upwd='123456';
(uname==='root' && upwd==='123456') ? console.log('登录成功') : console.log('登录失败');







