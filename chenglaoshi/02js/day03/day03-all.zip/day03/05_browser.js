//弹出警示框
//alert('please input uname');
//alert();
//弹出提示框
//var str=prompt('input age');
//console.log(str,typeof str);

var num1=prompt('input num1');
var num2=prompt('input num2');
//转为数值型
//把转换的结果覆盖之前的值
num1=Number(num1);
num2=Number(num2);

console.log(num1+num2);


