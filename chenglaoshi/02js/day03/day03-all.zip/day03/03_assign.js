var a=1;
//在当前的基础之上加1
//a++;
//a=a+1;
a+=1;
console.log(a);
//商品总价为500，打八折
//在原来基础之上打八折0.8
var price=500;
//price=price*0.8;
price*=0.8;
console.log(price);
