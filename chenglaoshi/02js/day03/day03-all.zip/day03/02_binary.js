console.log(1000>>4);
console.log(2<<4);
/*
    10
   100
  1000
 10000

*/