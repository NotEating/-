while(true){//循环条件
  //循环体
  console.log('hello');
}