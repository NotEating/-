//索引数组：数字做下标
//关联数组：字符串做下标
var emp=[];
emp['eid']=15;
emp['ename']='king';
emp['sex']='男';
//console.log(emp);
//练习: 创建数组，包含有多个用户数据(编号，用户名，密码，手机，邮箱)
var user=[
  {uid:1,uname:'ding',upwd:'1234',phone:'18012345678',email:'ding@163.com'},
  {uid:2,uname:'ding',upwd:'1234',phone:'18012345678',email:'ding@163.com'},
  {uid:3,uname:'ding',upwd:'1234',phone:'18012345678',email:'ding@163.com'}
];
//练习:创建一个对象，包含姓名，性别，爱好(音乐，旅游，游戏，敲代码)
var person={
  name:'king',
  sex:'男',
  love:['音乐','旅游','游戏','敲代码']
};
console.log(person);


