//查看一个人是否处于工作年龄（18~65）
var age=15;
//console.log( age>=18 && age<=65 );
//练习:声明变量保存用户名和密码，如果用户名为'root'，并且密码为'123456'，打印结果true，否则打印结果false
var uname='abc';
var upwd='123456';
//console.log( uname==='root' && upwd==='123456' );

//或者
//判断一个人是否属于老人或者儿童
var age=68;
//console.log( age<=12 || age>=65 );

//练习: 声明变量保存用户输入的值，该值为用户名'dangdang'或者该值为手机号码'18112345678'，如果有一个条件满足打印true，否则打印false
var input='dangdang';
//console.log( input==='dangdang' || input==='18112345678' );

var num=3;
//num>5  &&  console.log(a);
//num<1  ||  console.log(a);


//练习：声明变量保存年龄，如果满18岁，打印'成年人'
var age=12;
age>=18 && console.log('成年人');

//逻辑非
console.log( !true );
//运算符优先级
console.log( !5>3 );







