//整型
var num1=6;//十进制
var num2=011;//八进制
var num3=0XFF;//十六进制
//console.log(num3);
//浮点型
var num4=3.14;
var num5=3.14e3;
var num6=3.14e-3;
//console.log(num6);
//检测数据类型 typeof
//console.log(typeof num5);

//字符串型
var name='tom';
var str='1';
var str2='num6';
//console.log(str2,typeof str2);//string
//查看任意一个字符的Unicode码
//console.log( '的'.charCodeAt() );

//布尔型
var b1=true;
var b2=2>3;
//boolean
//console.log(b2,typeof b2);

//未定义型
var a;
//console.log(a,typeof a);

//空
var b=null;
console.log(b,typeof b);




