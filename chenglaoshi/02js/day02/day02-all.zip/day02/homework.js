//声明变量保存半径
var r=5;
//声明常量保存圆周率
const pi=3.14;
//计算周长和面积
var length=2*pi*r;
var area=pi*r*r;
console.log(length,area);
//console.log(0.1+0.2);

