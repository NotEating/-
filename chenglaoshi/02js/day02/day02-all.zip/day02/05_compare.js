//比较运算符
//console.log(3>2);
//console.log(2=='2');//true
//console.log(2==='2');//false
//console.log(0==false);//true
//console.log(0===false);//false
//字符串转成数值
//console.log(3>'10');
//比较Unicode码
//console.log('3'>'10');
//console.log( '的'.charCodeAt() );

//调用Number转数字  
//console.log( Number('10a') );//NaN
console.log(3>'10a');
console.log(3<'10a');
console.log(3=='10a');
console.log(NaN==NaN);








