//字面量
var str='javascript';
//构造函数————包装对象
var str2=new String('javascript');
//将任意的数据转为字符串
//普通函数
var str3=String([1,2,3]);

//console.log(typeof str);
//console.log(str2,typeof str2);
//console.log(str+'html');
//console.log(str2+'html');
//console.log(str3,typeof str3);

//打印 It's a dog
console.log('It\'s a dog');
//转换n为一个换行符
console.log('hello \n world');
//转换t为一个制表符(tab键)
console.log('wha\t are you');

console.log('welcome to chi\\na');





