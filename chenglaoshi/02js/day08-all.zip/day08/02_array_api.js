//var arr=['a','b','c','d'];
//翻转
//console.log( arr.reverse() );
/*
var arr=[23,9,78,6,45];
//默认按照Unicode码排序
//console.log( arr.sort() );
//按照数字从小到大
console.log( arr.sort(function(a,b){
  //return a-b;
  return b-a;
}) );
*/

var arr=['html','css','js'];
//在数组的末尾 添加元素
//arr[arr.length]='nodejs';
//作用 参数 返回值
//console.log( arr.push('ajax') );
//删除数组末尾的元素
//console.log( arr.pop() );


//开头添加元素
//console.log(arr.unshift('jquery'));
//删除开头元素
console.log( arr.shift() );
console.log(arr);
//splice




