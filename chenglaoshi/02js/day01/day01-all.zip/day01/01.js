console.log('hello world');
//console.log('javascript');
/*
 多行注释
*/

