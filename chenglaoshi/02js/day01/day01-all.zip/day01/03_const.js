//常量
const pi=3.14;
//练习：声明常量保存中秋节和国家的面积(960万)
const midautumn='八月十五';
const area=9600000;
console.log(midautumn,area);