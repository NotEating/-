//声明变量
var a=1;
var b=2;
//练习:声明多个变量，分别保存一个员工的编号，姓名，性别，生日，工资
var eid=8;
var ename='tom';
var sex='男';
var birthday='1997-1-2';
var salary=8000;
//console.log(eid,ename,sex,birthday,salary);
var 城市='北京';
//console.log(城市);

//变量的命名规则
var a1=5;
var _b3=7;
var $c=12;
//console.log($c);


var user_name=1;
var userPass=2;
var productCount=5;
//声明变量未赋值
var c;
c=3;
c=4;
c='hello';
//console.log(c);


var name='king',addr='bj',phone='18112345678';
//console.log(name,addr,phone);
// 练习: 声明多个变量，分别保存语文、数学、总成绩；计算总分（语文+数学），并把结果赋值给总成绩。打印总成绩
var chinese=95,math=97,total;
total=chinese+math;
console.log(total);






