//Number对象
var num1=2;//字面量
var num2=new Number(true);//object
var num3=Number(true);    //number
//console.log(num2,typeof num2);
//console.log(num3,typeof num3);
//console.log(num2+5);
//console.log(num3+5);

//console.log( Number.MAX_VALUE );
//console.log( Number.MIN_VALUE );

var area=3.14*5*5;//面积
var length=2*3.14*5;//周长
//console.log(area,length);
//获取小数点后n位
//console.log( length.toFixed(2) );
//var price=4999;
//console.log( price.toFixed(2) );

var num=18;
//String()  toString()  num+''
console.log( num.toString(8) );
