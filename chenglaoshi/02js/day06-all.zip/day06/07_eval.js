//弹出提示框  
var str=prompt();//字符串
//console.log(str,typeof str);
console.log( eval(str) );