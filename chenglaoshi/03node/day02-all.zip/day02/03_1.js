//引入03_2目录
var obj=require('./03_2');
console.log(obj);
console.log(obj.add(3,9));

