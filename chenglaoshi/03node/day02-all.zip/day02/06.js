//使用下载的包
var mysql=require('mysql');