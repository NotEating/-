//引入circle.js模块
//如果模块后缀名是js，可以省略
var circle=require('./circle');
console.log(circle);
//调用导出的函数
//console.log( circle.getLength(5).toFixed(2) );
//console.log( circle.getArea(5).toFixed(2) );
//circle.say(2,5);

console.log(__filename);
console.log(__dirname);


